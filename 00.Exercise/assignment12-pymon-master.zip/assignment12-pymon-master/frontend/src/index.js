import React from "react";
import ReactDOM from "react-dom";
import SimonGame from "./components/simongame"

ReactDOM.render(<SimonGame />, document.getElementById("game"));